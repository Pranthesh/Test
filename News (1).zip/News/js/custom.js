/***** Menu JS *****/

jQuery(document).ready(function() {
	jQuery('.enumenu_ul').responsiveMenu({
	'menuIcon_text': 'Menu',
	"menuslide_overlap":true,
	"menuslide_direction":'right',

	onMenuopen: function() {}
});

});


/***** Fix Header *****/

$(window).scroll(function(){
  if (jQuery(this).scrollTop() > 300) {
      jQuery('.header-bottom').addClass('fixed-header');
  } else {
      jQuery('.header-bottom').removeClass('fixed-header');
  }
});

/***** Dark/Light Mode *****/

 const btnDarkMode = document.querySelector("#toggle");
     const body = document.querySelector("html");
     btnDarkMode.addEventListener("click", (e) => {
     if (btnDarkMode.checked) {
     body.classList.remove("all");
     body.classList.add("dark");
     } else {
     body.classList.add("all");
     body.classList.remove("dark");
     }
 });


/***** Home Slider *****/

jQuery(document).ready(function () {
     // Swiper: Slider
     new Swiper(".home-slider", {
       loop: true,
       autoplay: false,
       speed: 2000,
       nextButton: ".swiper-button-next",
       prevButton: ".swiper-button-prev",
       slidesPerView: 1,
       paginationClickable: true,
       spaceBetween: 0,
       breakpoints: {
         1920: {
           slidesPerView: 1,
           spaceBetween: 0
         },
         1028: {
           slidesPerView: 1,
           spaceBetween: 0
         },
         480: {
           slidesPerView: 1,
           spaceBetween: 0
         }
       }
     });
     
     new Swiper(".swiper-slider-1", {
       loop: true,
       autoplay: false,
       speed: 2000,
       nextButton: ".swiper-button-next",
       prevButton: ".swiper-button-prev",
       slidesPerView: 1,
       paginationClickable: true,
       spaceBetween: 0,
       breakpoints: {
         1920: {
           slidesPerView: 1,
           spaceBetween: 0
         },
         1028: {
           slidesPerView: 1,
           spaceBetween: 0
         },
         480: {
           slidesPerView: 1,
           spaceBetween: 0
         }
       }
     });
});


/***** Tab Js *****/ 

jQuery(document).ready(function(){
   jQuery(".tab-item").click(function(){
       var filterValue = jQuery(this).attr('data-filter');
 
       jQuery('.filter-item').not('.'+filterValue).hide();
 
       jQuery('.filter-item').filter('.'+filterValue).show();
 
       jQuery(this).parent().find('.active').removeClass('active')
       jQuery(this).addClass('active');
   });
 });
 
 jQuery(document).ready(function(){
   jQuery(".tab-item-1").click(function(){
       var filterValue = jQuery(this).attr('data-filter');
 
       jQuery('.filter-item-1').not('.'+filterValue).hide();
 
       jQuery('.filter-item-1').filter('.'+filterValue).show();
 
       jQuery(this).parent().find('.active').removeClass('active')
       jQuery(this).addClass('active');
   });
});
 jQuery(document).ready(function(){
   jQuery(".tab-item-2").click(function(){
       var filterValue = jQuery(this).attr('data-filter');
 
       jQuery('.filter-item-2').not('.'+filterValue).hide();
 
       jQuery('.filter-item-2').filter('.'+filterValue).show();
 
       jQuery(this).parent().find('.active').removeClass('active')
       jQuery(this).addClass('active');
   });
});


/***** Scroll to Top Js *****/ 

var btn = jQuery('#top');

jQuery(window).scroll(function() {
  if (jQuery(window).scrollTop() > 500) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});

btn.on('click', function(e) {
  e.preventDefault();
  jQuery('html, body').animate({scrollTop:0}, '500');
});


